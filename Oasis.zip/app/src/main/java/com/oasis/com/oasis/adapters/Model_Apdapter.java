package com.oasis.com.oasis.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.github.florent37.expansionpanel.ExpansionHeader;
import com.github.florent37.expansionpanel.ExpansionLayout;
import com.github.florent37.expansionpanel.viewgroup.ExpansionLayoutCollection;
import com.oasis.R;
import com.oasis.com.oasis.models.Service_Model;

import java.util.ArrayList;
import java.util.List;

public class Model_Apdapter extends RecyclerView.Adapter<Model_Apdapter.RecyclerHolder> {
    private final List<Service_Model> list = new ArrayList<>();
    private final ExpansionLayoutCollection expansionsCollection = new ExpansionLayoutCollection();
    public Model_Apdapter(){
        expansionsCollection.openOnlyOne(true);
    }
    @NonNull
    @Override
    public RecyclerHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return RecyclerHolder.buildFor(parent);
    }
    @Override
    public void onBindViewHolder(RecyclerHolder holder, int position) {
        holder.bind(list.get(position));
        expansionsCollection.add(holder.getExpansionLayout());
    }
    @Override
    public int getItemCount() {
        return list.size();
    }
    public void setItems(List<Service_Model> items){
        this.list.addAll(items);
        notifyDataSetChanged();
    }
    public final static class RecyclerHolder extends RecyclerView.ViewHolder {
        private TextView sid,name,date,servicetype,productname,productid,head_name;
        private static final int LAYOUT = R.layout.service_model;
        ExpansionLayout expansionLayout;
        ExpansionHeader expansionHeader;

        public static RecyclerHolder buildFor(ViewGroup viewGroup){
            return new RecyclerHolder(LayoutInflater.from(viewGroup.getContext()).inflate(LAYOUT, viewGroup, false));
        }

        public RecyclerHolder(View itemView) {
            super(itemView);
            expansionHeader = itemView.findViewById(R.id.expansionheader);
            expansionLayout = itemView.findViewById(R.id.expansionLayout);
        }

        public void bind(Service_Model service_model){
            head_name = expansionHeader.findViewById(R.id.head_name);
            head_name.setText(service_model.getName());
            sid = expansionLayout.findViewById(R.id.sid);
            name = expansionLayout.findViewById(R.id.name);
            date = expansionLayout.findViewById(R.id.date);
            servicetype = expansionLayout.findViewById(R.id.servicetype);
            productname = expansionLayout.findViewById(R.id.productname);
            productid = expansionLayout.findViewById(R.id.productid);
            productid.setText(service_model.getProduct_id());
            productname.setText(service_model.getProduct_name());
            sid.setText(service_model.getService_id());
            date.setText(service_model.getDate());
            name.setText(service_model.getName());
            servicetype.setText(service_model.getService_type());
            expansionLayout.collapse(false);
        }

        public ExpansionLayout getExpansionLayout() {
            return expansionLayout;
        }
    }
}
